naam = input("Hallo, wat is je naam? ")
leeftijd = input(f"Goedendag {naam}, Hoe oud ben je? ")
favoriete_eten = input(f"En als {leeftijd} jarige, wat eet je het liefst? ")
favoriete_drinken = input(f"En wat drink je het liefst bij je {favoriete_eten}? ")

print(f"De {leeftijd} jarige {naam} drinkt het liefst {favoriete_drinken} bij {favoriete_eten}")